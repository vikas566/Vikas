# Synchronized TTS Highlighting

React frontend app using Web Speech API with real-time word highlighting.
