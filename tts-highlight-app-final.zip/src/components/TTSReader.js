import React, { useEffect, useRef, useState } from 'react';
import { Box, Button, Select, MenuItem, Slider, Typography, Paper } from '@mui/material';

const text = `The objective of this task is to design and implement a frontend only solution
that synchronizes text to speech audio playback with real time text highlighting.`;

export default function TTSReader() {
  const words = text.split(/\s+/);
  const utteranceRef = useRef(null);

  const [voices, setVoices] = useState([]);
  const [voiceURI, setVoiceURI] = useState('');
  const [rate, setRate] = useState(1);
  const [activeIndex, setActiveIndex] = useState(-1);
  const [speaking, setSpeaking] = useState(false);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    const loadVoices = () => {
      const allVoices = window.speechSynthesis.getVoices();
      const langs = ['hi-IN','gu-IN','mr-IN','ta-IN','te-IN'];
      const filtered = allVoices.filter(v => langs.includes(v.lang));
      setVoices(filtered);
      if (filtered.length) setVoiceURI(filtered[0].voiceURI);
    };
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
  }, []);

  const getVoice = () => voices.find(v => v.voiceURI === voiceURI);

  const play = () => {
    stop();
    const utter = new SpeechSynthesisUtterance(text);
    utter.voice = getVoice();
    utter.rate = rate;
    utter.onboundary = e => {
      if (e.name === 'word') {
        let count = 0;
        for (let i = 0; i < words.length; i++) {
          count += words[i].length + 1;
          if (e.charIndex < count) {
            setActiveIndex(i);
            break;
          }
        }
      }
    };
    utter.onend = stop;
    utteranceRef.current = utter;
    window.speechSynthesis.speak(utter);
    setSpeaking(true);
    setPaused(false);
  };

  const pause = () => { window.speechSynthesis.pause(); setPaused(true); setSpeaking(false); };
  const resume = () => { window.speechSynthesis.resume(); setPaused(false); setSpeaking(true); };
  const stop = () => {
    window.speechSynthesis.cancel();
    setActiveIndex(-1);
    setSpeaking(false);
    setPaused(false);
  };

  return (
    <>
      <Paper sx={{ p:2, mb:2 }}>
        <Box sx={{ display:'flex', gap:2, flexWrap:'wrap' }}>
          <Button variant="contained" onClick={play}>Play</Button>
          <Button variant="outlined" onClick={pause} disabled={!speaking}>Pause</Button>
          <Button variant="outlined" onClick={resume} disabled={!paused}>Resume</Button>
          <Button variant="contained" color="error" onClick={stop}>Stop</Button>

          <Select size="small" value={voiceURI} onChange={e=>{setVoiceURI(e.target.value);stop();}}>
            {voices.map(v=>(
              <MenuItem key={v.voiceURI} value={v.voiceURI}>
                {v.name} ({v.lang})
              </MenuItem>
            ))}
          </Select>

          <Box sx={{ width:150 }}>
            <Typography variant="caption">Rate</Typography>
            <Slider value={rate} min={0.5} max={2} step={0.1} onChange={(e,v)=>setRate(v)} />
          </Box>
        </Box>
      </Paper>

      <Paper sx={{ p:2 }}>
        <Typography component="div" sx={{ lineHeight:2 }}>
          {words.map((w,i)=>(
            <span key={i} style={{
              background:i===activeIndex?'yellow':'transparent',
              fontWeight:i===activeIndex?'bold':'normal',
              marginRight:4
            }}>{w}</span>
          ))}
        </Typography>
      </Paper>
    </>
  );
}
