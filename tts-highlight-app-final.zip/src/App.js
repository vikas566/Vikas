import React from 'react';
import { Container, Typography } from '@mui/material';
import TTSReader from './components/TTSReader';

function App() {
  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Typography variant="h4" gutterBottom>
        Synchronized TTS Highlighting
      </Typography>
      <TTSReader />
    </Container>
  );
}

export default App;
